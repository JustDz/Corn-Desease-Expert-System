/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package corndiseaseexpertsystem;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Asus
 */
public class Burn 
{
    private ArrayList<String> questions;
    private int answers[];
    
    public Burn()
    {
        this.answers = new int[4];
        this.questions = new ArrayList<String>();
        this.setQuestions();
    }
    
    public void setQuestions()
    {
        //Q1
        questions.add("Apakah terdapat pembengkakan pada tongkol?");
        //Q2
        questions.add("Apakah biji jagung membengkak?");
        //Q3
        questions.add("Apakah terdapat kelenjar yang terbentuk pada biji jagung?");
        //Q4
        questions.add("Apakah terdapat kelobot yang terbuka dan muncul banyak jamur putih hingga hitam?");
    }
   
    public void showQuestion()
    {
        Scanner sc = new Scanner(System.in);
        int i =0;
        for(String q: this.questions)
        {
            System.out.println(q);
            System.out.println("0. Tidak    1.Ya");
            int a = sc.nextInt();
            while(a != 0 && a!=1)
            {
                System.out.println("Jawaban tidak sesuai!");
                a = sc.nextInt();
            }
            answers[i] = a;
            i++;
        }
    }
    
    public Set<String> getFacts()
    {
        Set<String> facts = new HashSet<>();
        if(answers[0] == 1)
            facts.add("g15");
        if(answers[1] == 1)
            facts.add("g17");
        if(answers[2] == 1)
            facts.add("g18");
        if(answers[3] == 1)
            facts.add("g19");
        return facts;
    }
    
    public void showConclussion(boolean BurnIsTrue, Set<String> facts, Set<String> inferedFacts)
    {
        System.out.println("All facts: " + facts);
        System.out.println("Inferred facts: " + inferedFacts);
        if(BurnIsTrue == true)
        {
            System.out.println("Jagung terinfeksi Burn");
        }
        else
        {
            System.out.println("Jagung dalam kondisi aman :D");
        }
    }
}