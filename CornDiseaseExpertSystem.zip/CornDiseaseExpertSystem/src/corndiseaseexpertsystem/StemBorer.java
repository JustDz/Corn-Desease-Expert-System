/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package corndiseaseexpertsystem;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Asus
 */
public class StemBorer 
{
    private ArrayList<String> questions;
    private int answers[];
    
    public StemBorer()
    {
        this.answers = new int[7];
        this.questions = new ArrayList<String>();
        this.setQuestions();
    }
    
    public void setQuestions()
    {
        //Q1
        questions.add("Apakah terdapat lubang kecil pada daun?");
        //Q2
        questions.add("Apakah terdapat kotoran disekitar pengangkat?");
        //Q3
        questions.add("Apakah terdapat bunga jantan atau pangkal tongkol?");
        //Q4
        questions.add("Apakah batang dan malai mudah patah?");
        //Q5
        questions.add("Apakah terdapat tumpukan malai yang patah?");
        //Q6
        questions.add("Apakah bunga jantan tidak dapat terbentuk?");
        //Q7
        questions.add("Apakah terdapat kekuningan pada sekitar daun?");
    }
   
    public void showQuestion()
    {
        Scanner sc = new Scanner(System.in);
        int i =0;
        for(String q: this.questions)
        {
            System.out.println(q);
            System.out.println("0. Tidak    1.Ya");
            int a = sc.nextInt();
            while(a != 0 && a!=1)
            {
                System.out.println("Jawaban tidak sesuai!");
                a = sc.nextInt();
            }
            answers[i] = a;
            i++;
        }
    }
    
    public Set<String> getFacts()
    {
        Set<String> facts = new HashSet<>();
        if(answers[0] == 1)
            facts.add("g20");
        if(answers[1] == 1)
            facts.add("g26");
        if(answers[2] == 1)
            facts.add("g22");
        if(answers[3] == 1)
            facts.add("g23");
        if(answers[4] == 1)
            facts.add("g24");
        if(answers[5] == 1)
            facts.add("g25");
        if(answers[6] == 1)
            facts.add("g27");
        return facts;
    }
    
    public void showConclussion(boolean SBIsTrue, Set<String> facts, Set<String> inferedFacts)
    {
        System.out.println("All facts: " + facts);
        System.out.println("Inferred facts: " + inferedFacts);
        if(SBIsTrue == true)
        {
            System.out.println("Jagung terinfeksi StemBorer");
        }
        else
        {
            System.out.println("Jagung dalam kondisi aman :D");
        }
    }
}