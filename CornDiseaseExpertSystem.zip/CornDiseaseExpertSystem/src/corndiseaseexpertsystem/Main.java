package corndiseaseexpertsystem;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {

    public static List<Rule> getKnowledge() throws FileNotFoundException, IOException {
        FileReader reader = new FileReader("D:\\Documents\\Kuliah\\Semester 5\\SisPak\\CornDiseaseExpertSystem\\src\\corndiseaseexpertsystem\\knowledge_base");
        BufferedReader bufferedReader = new BufferedReader(reader);
        List<Rule> rules = new ArrayList<>();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] parts = line.split("-");
            List<String> symptoms = Arrays.asList(parts[0].split(","));
            String conclusion = parts[1];
            rules.add(new Rule(symptoms, conclusion));
        }
        
        bufferedReader.close();
        reader.close();
        return rules;
    }
    
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        List<Rule> rules = getKnowledge(); 
        boolean running = true;
        
        while (running) {    
            System.out.println("===== Sistem Pengecek Penyakit Jagung =====");
            System.out.println("===========================================");
            System.out.println("Pilih Jenis Penyakit :\n"
                             + "1. Bulai          4. Burn\n"
                             + "2. Blight         5. StemBorer\n"
                             + "3. LeafRust       6. CobBorer\n"
                             + "Jawab: ");
            
            int PilihPenyakit = input.nextInt();
            
            Set<String> facts = null;
            Set<String> inferedFacts = null;
            
            switch(PilihPenyakit) {
                case 1:
                    Bulai bulai = new Bulai();  
                    bulai.showQuestion();
                    facts = bulai.getFacts();
                    inferedFacts = InferenceForwardChaining.doForwardChaining(rules, facts);

                    boolean BulmaIsTrue = inferedFacts.contains("p001");
                    bulai.showConclussion(BulmaIsTrue, facts, inferedFacts);
                    break;
                    
                case 2:
                    Blight blight = new Blight();
                    blight.showQuestion();
                    facts = blight.getFacts();
                    inferedFacts = InferenceForwardChaining.doForwardChaining(rules, facts);

                    boolean BlightIsTrue = inferedFacts.contains("p002");
                    blight.showConclussion(BlightIsTrue, facts, inferedFacts);
                    break;
                    
                case 3:
                    LeafRust lr = new LeafRust();
                    lr.showQuestion();
                    facts = lr.getFacts();
                    inferedFacts = InferenceForwardChaining.doForwardChaining(rules, facts);

                    boolean LRIsTrue = inferedFacts.contains("p003");
                    lr.showConclussion(LRIsTrue, facts, inferedFacts);
                    break;
                    
                case 4:
                    Burn burn = new Burn();
                    burn.showQuestion();
                    facts = burn.getFacts();
                    inferedFacts = InferenceForwardChaining.doForwardChaining(rules, facts);

                    boolean BurnIsTrue = inferedFacts.contains("p004");
                    burn.showConclussion(BurnIsTrue, facts, inferedFacts);
                    break;
                    
                case 5:
                    StemBorer sb = new StemBorer();
                    sb.showQuestion();
                    facts = sb.getFacts();
                    inferedFacts = InferenceForwardChaining.doForwardChaining(rules, facts);

                    boolean SBIsTrue = inferedFacts.contains("p005");
                    sb.showConclussion(SBIsTrue, facts, inferedFacts);
                    break;
                    
                case 6:
                    CobBorer cb = new CobBorer();
                    cb.showQuestion();
                    facts = cb.getFacts();
                    inferedFacts = InferenceForwardChaining.doForwardChaining(rules, facts);

                    boolean CBIsTrue = inferedFacts.contains("p006");
                    cb.showConclussion(CBIsTrue, facts, inferedFacts);
                    break;
                    
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
            
            System.out.println("\nIngin mengecek penyakit lain? (Y/N)");
            String jawab = input.next();
            if (jawab.equalsIgnoreCase("N")) {
                System.out.println("Terimakasih Telah Mencoba!");
                running = false;
            }
        }
    }
}
