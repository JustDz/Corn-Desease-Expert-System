/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package corndiseaseexpertsystem;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Asus
 */
public class Bulai 
{
    private ArrayList<String> questions;
    private int answers[];
    
    public Bulai()
    {
        this.answers = new int[4];
        this.questions = new ArrayList<String>();
        this.setQuestions();
    }
    
    public void setQuestions()
    {
        //Q1
        questions.add("Apakah daun jagung berwarna klorotik?");
        //Q2
        questions.add("Apakah terdapat warna putih diatas dan bawah daun yang klorotik?");
        //Q3
        questions.add("Apakah jagung mengalami hambatan pertumbuhan?");
        //Q4
        questions.add("Apakah jagung mengalami gangguan pembentukan tongkol");
    }
   
    public void showQuestion()
    {
        Scanner sc = new Scanner(System.in);
        int i =0;
        for(String q: this.questions)
        {
            System.out.println(q);
            System.out.println("0. Tidak    1.Ya");
            int a = sc.nextInt();
            while(a != 0 && a!=1)
            {
                System.out.println("Jawaban tidak sesuai!");
                a = sc.nextInt();
            }
            answers[i] = a;
            i++;
        }
    }
    
    public Set<String> getFacts()
    {
        Set<String> facts = new HashSet<>();
        if(answers[0] == 1)
            facts.add("g1");
        if(answers[1] == 1)
            facts.add("g3");
        if(answers[2] == 1)
            facts.add("g2");
        if(answers[3] == 1)
            facts.add("g5");
        return facts;
    }
    
    public void showConclussion(boolean BulaiIsTrue, Set<String> facts, Set<String> inferedFacts)
    {
        System.out.println("All facts: " + facts);
        System.out.println("Inferred facts: " + inferedFacts);
        if(BulaiIsTrue == true)
        {
            System.out.println("Jagung terinfeksi Bulai");
        }
        else
        {
            System.out.println("Jagung dalam kondisi aman :D");
        }
    }
}
